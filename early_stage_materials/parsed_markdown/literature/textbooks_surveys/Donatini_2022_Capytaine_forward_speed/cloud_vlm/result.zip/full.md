# IMPLEMENTATION OF FORWARD SPEED EFFECTS ON AN OPEN SOURCESEAKEEPING SOLVER

Luca Donatini, Maritime Technology Division, Ghent University, Belgium

Ivandito Herdayanditya, Department of Civil Engineering, KU Leuven, Belgium and Maritime Technology Division, Ghent University, Belgium

Gael Verao Fernandez, Coastal Engineering, Bridges and Roads Research Group, Ghent University, Belgium

Ajie Brama Krishna Pribadi and Evert Lataire, Maritime Technology Division, Ghent University, Belgium

Guillaume Delefortrie, Flanders Hydraulics Research, Belgium and Maritime Technology Division, Ghent University, Belgium

# SUMMARY

This paper describes the theoretical and practical aspects of a first implementation of forward speed effects into the open source potential flow seakeeping solver Capytaine, which solves the 3D boundary value problems (BVP) of wave radiation and diffraction in the frequency domain. The effects of forward speed are included by correcting the results of the BVPs solved with zero speed Green’s functions, according to the approach usually referred to as Approximate Forward Speed (AFS). This approach, only partially documented in literature, was never implemented before in an open source 3D code for the solution of the seakeeping problem in the frequency domain. The theoretical aspects, as well as the practical challenges of an implementation in Capytaine are explored in detail in this paper. The results of applying the code to the KCS container ship are presented and compared with the results obtained using the state-of-the-art commercial code HydroStar.

NOMENCLATURE 

<table><tr><td> $A_{jk}$ </td><td>Radiation added mass coefficient</td></tr><tr><td> $B_{jk}$ </td><td>Radiation damping coefficient</td></tr><tr><td> $\vec{F}$ </td><td>Generalized 6D force vector</td></tr><tr><td> $\widetilde{F_{j}^{\text{UL}}}$ </td><td>Unsteady generic linear wave force</td></tr><tr><td> $F_{j}^{\text{UL}} = F_{j}$ </td><td>Phasor of the unsteady wave force</td></tr><tr><td> $F_{j}^{\text{FK}}$ </td><td>Phasor of the Froude-Krylov force</td></tr><tr><td> $F_{j}^{\text{D}}$ </td><td>Phasor of the diffraction force</td></tr><tr><td> $F_{jk}^{\text{R}}$ </td><td>Phasor of the radiation force</td></tr><tr><td> $g$ </td><td>Gravity acceleration (m/s2)</td></tr><tr><td> $h$ </td><td>Water depth (m)</td></tr><tr><td> $k$ </td><td>Regular wave number (-)</td></tr><tr><td> $_{j}$ </td><td>force DOF index</td></tr><tr><td> $_{k}$ </td><td>motion DOF index</td></tr><tr><td> $m_{k}$ </td><td>m-terms</td></tr><tr><td> $\vec{n}$ </td><td>Generalized 6D normal vector</td></tr><tr><td> $p$ </td><td>Pressure (Pa)</td></tr><tr><td> $_{p}$ </td><td>panel index</td></tr><tr><td> $p^{\text{S}}$ </td><td>Steady part of the pressure (Pa)</td></tr><tr><td> $\widetilde{p^{\text{U}}}$ </td><td>Unsteady part of the pressure (Pa)</td></tr><tr><td> $p^{\text{U}}$ </td><td>Phasor of the unsteady pressure (Pa)</td></tr><tr><td> $p^{\text{UL}}$ </td><td>Linearised phasor of  $\widetilde{p^{\text{U}}}$  (Pa)</td></tr><tr><td> $\vec{r}$ </td><td>Position vector</td></tr><tr><td> $S_{0}$ </td><td>Wetted surface in still water (m2)</td></tr><tr><td> $U$ </td><td>Ship’s forward speed (m/s)</td></tr><tr><td> $\varepsilon$ </td><td>Regular wave phase (rad)</td></tr><tr><td> $\zeta_{\text{A}}$ </td><td>Regular wave amplitude (m)</td></tr><tr><td> $\lambda$ </td><td>Regular wave length (m)</td></tr><tr><td> $\mu$ </td><td>Incident angle of the waves (rad)</td></tr><tr><td> $\vec{v}$ </td><td>Normal direction 3D vector</td></tr><tr><td> $\xi_{j}$ </td><td>Amplitudes of ship motions in 6DOF</td></tr><tr><td> $\rho$ </td><td>Density of water (kg/m3)</td></tr><tr><td> $\phi^{\text{BF}}$ </td><td>Base flow potential</td></tr></table>

<table><tr><td> $\phi^{DB}$ </td><td>Double body potential</td></tr><tr><td> $\phi^{SW}$ </td><td>Steady waves potential</td></tr><tr><td> $\overline{\phi^{UW}}$ </td><td>Unsteady wave potential</td></tr><tr><td> $\phi^{UW}$ </td><td>Phasor of the unsteady wave potential</td></tr><tr><td> $\phi_{0}$ </td><td>Incident wave potential (phasor)</td></tr><tr><td> $\phi_{7}$ </td><td>Diffraction potential (phasor)</td></tr><tr><td> $\phi_{k}$ </td><td>Radiation potentials in 6DOF (phasors)</td></tr><tr><td> $\omega$ </td><td>Regular wave angular frequency (rad/s)</td></tr><tr><td> $\omega_{e}$ </td><td>Encounter angular frequency (rad/s)</td></tr><tr><td>AFS</td><td>Approximate Forward Speed approach</td></tr><tr><td>BVP</td><td>Boundary Value Problem</td></tr><tr><td>CoB</td><td>Center of Buoyancy</td></tr><tr><td>DOF</td><td>Degree of freedom</td></tr><tr><td>EFS</td><td>Exact Forward Speed approach</td></tr><tr><td>h-frame</td><td>Horizontal bound coordinate system</td></tr><tr><td>KCS</td><td>KRISO Container Ship</td></tr><tr><td>LHS</td><td>Left-Hand Side</td></tr><tr><td>RHS</td><td>Right-Hand Side</td></tr><tr><td>TPS</td><td>Translating Pulsating Sources</td></tr></table>

# 1 INTRODUCTION

The forces acting on a body in waves are usually modelled with potential flow methods, due to the limited importance of viscous effects on the problem. Among potential flow methods, there exist several alternative approaches to model the problem, both in the frequency and in the time domain. In the frequency domain the problem is usually modelled with 2D strip theory methods or with 3D methods based on Kelvin Green’s functions. In the time domain, the more advanced Rankine source methods are commonly used.

Despite the large variety of methods to solve the problem, only a few open source seakeeping codes exist, and only one of them is presently capable of including the effects of forward speed. This is the open source code PDStrip (Bertram et al., 2006), based on strip theory. Strip theory codes have long since included the effects of forward speed, according to the approach described in (Salvesen et al., 1970). The huge advantage of strip theory codes is their computational efficiency, with simulation times in the order of seconds on modern computers. However, the applicability of strip theory is severely limited by the strict requirements on the body geometry, linked with the impossibility to model 3-dimensional flows.

On the opposite side of the spectrum of seakeeping codes one can find the Rankine source time domain methods, which provide more accurate results at the expense of much longer simulation times. Rankine source codes use Rankine Green’s function sources distributed over both the body surface and the free surface. This, together with the time domain approach, provides more flexibility in the definition of the Free Surface Boundary Condition (FSBC), allowing to model the effects of forward speed in a more accurate way which accounts also for the interaction between the resistance wave pattern and the incident, radiated and diffracted waves. While most of the available Rankine source codes are research tools (Kim et al., 2011; Mantzaris, 1998), and a single commercial package exists (Söding et al., 2012), no open source implementations are available.

In between strip theory and Rankine source methods, in terms of both physical accuracy and computational cost, lies a class of seakeeping codes which solve the 3D Boundary Value Problems (BVPs) describing the wave radiation and diffraction of floating bodies in the frequency domain. These codes, which are based on a distribution of Kelvin Green’s function sources on the 3D wetted surface of the body only, will be defined in the following simply as 3D panel codes for brevity. 3D panel codes offer rather fast simulation times, in the order of minutes up to some hours, and allow to model 3D flow effects.

In recent years, several open source 3D panel codes were made available, like Nemoh (Babarit and Delhommeau, 2015) and the derived code Capytaine (Ancellin and Dias, 2019), or the HAMS code (Liu, 2019). While a few of the commercially available 3D panel codes, such as HydroStar (Chen, 2011), include the effects of forward speed, to the authors knowledge none of the open source alternatives does. The effects of forward speed can be included in a 3D panel code either directly, by using forward speed Green’s functions, or indirectly, by correcting the results of the BVPs solved with zero speed Green’s functions (Bunnik et al., 2010; Hizir et al., 2019). A comparison of the two methods was performed in (Chapchap et al., 2011), without outlining a clear advantage of using one or the other method.

Forward speed Green’s functions in the frequency domain, also called Translating Pulsating Sources (TPS), are mathematically quite complex and rather burdensome to calculate (Beck and Reed, 2001; Hizir, 2015). A detailed example of their calculation can be found in (Iwashita and Ohkusu, 1992), while a more recent application can be found in (Datta et al., 2013). The approach of modelling forward speed based on the use of TPS is usually referred to as the Exact Forward Speed (EFS) method. Because of its complexity, the EFS method has always been used more in academical applications than in practical ones, and no publicly available seakeeping code which implements TPS presently exists. In the recent years, the research on TPS has lost popularity in favour of the Rankine source methods.

The approach of modelling forward speed effects as corrections to the results of BVPs solved with zero speed Green’s functions is usually referred to in literature as the Approximate Forward Speed (AFS) approach. A complete overview on different methods to calculate the zero speed Green’s function was recently published by (Xie et al., 2018). Some details about the AFS approach can be found scattered in several publications, but a comprehensive reference is not available. Moreover, the different publications sometimes adopt different conventions, which in some cases are not fully reported, resulting in apparently different formulations. The AFS approach originates from the pioneering work of (Salvesen et al., 1970), which was extended to a 3D flow model in (Papanikolaou and Schellin, 1992). A slightly different approach than the one followed in (Papanikolaou and Schellin, 1992) is based on an expansion of the potentials with perturbation series based on two independent small parameters, the wave slope and a non-dimensional speed coefficient. This approach leads to similar formulations for the forces acting on a floating body with small forward speed, as described in (Emmerhoff and Sclavounos, 1992; Nossen et al., 1991). The AFS method corrects the diffraction and radiation forces based on the fluid velocities in the direction of the forward speed due to respectively diffracted and radiated waves. The commercial seakeeping software HydroStar uses by default the AFS approach to model forward speed, but the details of its implementation are not fully disclosed. Additional notable sources where the AFS approach is briefly discussed are (Hizir, 2015; Tuitman and Malenica, 2009).

The absence of modern and accurate open source seakeeping codes which can deal with forward speed is surely a disadvantage for the community of researchers who focus on naval hydrodynamics. Furthermore, ships underway are not the only practical application for forward speed effects: fixed objects subjected to waves and current can be simulated as well with the same technique, using a forward speed equal and opposite to the desired current speed. An example of the latter type of simulations is the calculation of hydrodynamic forces acting on monopile foundations of offshore installations, frequently subjected to the combined action of current and waves.

In this paper, an implementation of forward speed effects in the open source code Capytaine is investigated. A comprehensive theoretical overview of the AFS approach is presented in chapter 2. This expands and clarifies the approach presented in (Papanikolaou and Schellin, 1992). The practical challenges in implementing the AFS method in Capytaine and in comparing the results with the ones from HydroStar are explored in chapter 3. The results obtained for the benchmark hull shape KCS are presented in chapter 4, and validated against the results obtained with the commercial code HydroStar. Finally, conclusions are drawn in chapter 0.

# 2 THEORETICAL BACKGROUND

# 2.1 REFERENCE COORDINATE SYSTEM

The coordinate system used in this paper is a horizontalbound coordinate system (h-frame), ?? − ?????? which follows the ship. The ?? axis is positive forward, the ?? axis is positive to port and the ?? axis is positive upwards.

The ship is considered to advance at a constant forward speed ?? in the ?? direction (no drift). In the h-frame, this problem can also be described as a steady ship performing wave induced oscillations in a uniform flow of velocity ?? in the negative ?? direction, without considering any wavecurrent interaction effects.

# 2.2 REFERENCE WAVE

A regular wave can be completely defined by four parameters: the wave angular frequency ??, the wave phase ??, the wave amplitude $\zeta _ { \mathrm { A } }$ and the water depth ℎ. The wave length ?? is usually expressed as a spatial frequency called wave number ??:

$$
k = \frac {2 \pi}{\lambda} \tag {1}
$$

The wave number is univocally defined based on ?? and ℎ according to the real solution of the general dispersion relation:

$$
\omega^ {2} = g k \tanh k h \tag {2}
$$

Due to the Doppler effect, in the h-frame defined above a regular wave is observed with a different angular frequency called the encounter frequency $\omega _ { e }$ . The encounter frequency can be calculated as:

$$
\omega_ {e} = \omega - k U \cos (\mu) \tag {3}
$$

where $\mu$ is the incident angle of the waves, or the angle between the ?? axis of the h-frame and the direction of propagation of the regular wave.

In the h-frame the free surface elevation induced by a regular wave can be expressed as:

$$
\zeta (x, y, t) = \Re \left(\zeta_ {\mathrm{A}} e ^ {i k (x \cos (\mu) + y \sin (\mu))} e ^ {- i \omega_ {e} t} e ^ {i \varepsilon}\right) \tag {4}
$$

# 2.3 POTENTIAL DECOMPOSITION

The total velocity complex potential Φ can be decomposed into three main parts:

$$
\Phi = \phi^ {\mathrm{BF}} (\vec {x}) + \phi^ {\mathrm{SW}} (\vec {x}) + \widetilde {\phi^ {\mathrm{UW}}} (\vec {x}, t) \tag {5}
$$

where: ??BF = base flow potential

$$
\phi^ {\mathrm{SW}} = \text { steady   wave   potential }
$$

$$
\widetilde {\phi^ {\mathrm{UW}}} = \text {   unsteady   wave   potential   (seakeeping)   }
$$

$$
\vec {x} \quad = \quad \text { space   coordinate   vector   in   the   h - frame }
$$

The base flow potential $\phi ^ { \mathrm { B F } }$ can be either the uniform flow $- U x$ , under the assumption of a thin ship, or the double body-flow $\phi ^ { \mathrm { D B } }$ (Hizir, 2015; Nakos, 1990). The steady wave potential $\phi ^ { \mathrm { { s w } } }$ is linked with the resistance problem, for which a comprehensive overview can be found in (Raven, 1996).

In the frequency domain approach to the seakeeping problem, the responses of a body to a regular wave are investigated. According to the fundamental assumption of linearity at the basis of the frequency domain approach, all the results of the analysis (e.g. fluid velocities and pressure, forces on the body) are harmonically oscillating with the same frequency of the regular wave, as seen from the selected frame of reference. Therefore, when adopting the frequency domain approach to solve the seakeeping problem in the h-frame, the unsteady wave potential is harmonically oscillating in time at the encounter frequency $\omega _ { e }$ and it can be decomposed into a phasor, or complex amplitude, and an oscillatory term:

$$
\widetilde {\phi^ {\mathrm{UW}}} (\vec {x}, t) = \phi^ {\mathrm{UW}} (\vec {x}) \cdot e ^ {- i \omega_ {e} t} \tag {6}
$$

The phasor of the unsteady wave potential, which can also be called the frequency domain potential, can be further decomposed as:

$$
\phi^ {\mathrm{UW}} (\vec {x}) = \zeta_ {\mathrm{A}} \cdot (\phi_ {0} + \phi_ {7}) + \sum_ {k = 1} ^ {6} \xi_ {k} \phi_ {k} \tag {7}
$$

where: ??0 = incident wave potential (phasor)

$$
\phi_ {7} = \text {   diffraction   potential   (phasor)   }
$$

$$
k = \text { index   of   the   radiation   motion   (DOF) }
$$

$$
\xi_ {k} \quad = \quad \text { amplitudes   of   ship   motions   in   6DOF }
$$

$$
\phi_ {k} = \text { radiation   potentials   in   6DOF   (phasors) }
$$

The phasor of the incident wave potential for a unit amplitude of the regular wave, $\phi _ { 0 } ,$ , can be expressed analitically as:

$$
\phi_ {0} = - \frac {i g}{\omega} \frac {\cosh [ k (z + h) ]}{\cosh (k h)} e ^ {i k (x \cos (\mu) + y \sin (\mu))} \tag {8}
$$

The phasors of the diffraction and radiation potentials can be obtained by solving the related seakeeping problems in the frequency domain. Both the diffraction and the radiation problems can be solved by imposing the continuity equation on the fluid domain, the free surface boundary conditions on the free surface, the radiation boundary condition on infinity and an impermeability condition on both the sea floor and the hull (body boundary condition). When using Kelvin Green’s functions to solve the problem, the continuity equation, free surface boundary conditions, radiation boundary condition and sea floor boundary condition are automatically satisfied by the Green’s functions, and the problem can be reduced to modelling a distribution of Kelvin sources on the hull surface. The problem is solved by imposing an impermeability condition on the hull surface in still water $S _ { 0 }$ .

The normal direction ??⃗ to a generic surface ?? at a specific point identified by the position vector $\vec { r }$ can be expressed as a normalized 3D vector. In order to simplify the following discussion, a generalized normal vector with 6 components is introduced: $\vec { n } = [ n _ { 1 } , n _ { 2 } , n _ { 3 } , n _ { 4 } , n _ { 5 } , n _ { 6 } ]$ . The first three components of the generalized normal vector are the components of the normal direction ??⃗ in the ??, ?? and ?? axes, while the last three components can be calculated as the cross product between the position vector and the normal direction vector:

$$
\begin{array}{l} {[ n _ {1}, n _ {2}, n _ {3} ] = [ \nu_ {x}, \nu_ {y}, \nu_ {z} ]} \\ {[ n _ {4}, n _ {5}, n _ {6} ] = \vec {r} \times \vec {\nu}} \end{array} \tag {9}
$$

For the diffraction problem, the body boundary condition reads:

$$
\left. \frac {\partial \phi_ {7}}{\partial n} \right| _ {S _ {0}} = - \left. \frac {\partial \phi_ {0}}{\partial n} \right| _ {S _ {0}} \tag {10}
$$

For the radiation problems, on the other hand, the body boundary conditions read:

$$
\left. \tilde {\xi} _ {k} \frac {\partial \phi_ {k}}{\partial n} \right| _ {S _ {0}} = \frac {\partial \tilde {\xi} _ {k}}{\partial t} n _ {k} + U \left. \tilde {\xi} _ {k} m _ {k} \right| _ {S _ {0}} \quad \forall k = 1, \dots , 6 (1 1)
$$

where $m _ { k }$ are the so called m-terms, resulting by the interaction of the unsteady wave potential with the base flow potential in the linearized body boundary condition (Nakos, 1990; Papanikolaou and Schellin, 1992). $\xi _ { k }$ are the harmonic motions of the body. Since the harmonic motions of the body in one of the 6 DOFs can be expressed as $\tilde { \xi } _ { k } = \xi _ { k } e ^ { - i \omega _ { e } t }$ , equation (11) can be rewritten as:

$$
\left. \frac {\partial \phi_ {k}}{\partial n} \right| _ {S _ {0}} = - i \omega_ {e} n _ {k} + U m _ {k} | _ {S _ {0}} \quad \forall k = 1, \dots , 6 \tag {12}
$$

When the base flow is approximated by the uniform flow $- U x$ , the only non-zero ??-terms are:

$$
\begin{array}{l} m _ {5} = n _ {3} \\ m _ {6} = - n _ {2} \end{array} \tag {13}
$$

An alternative formulation to take into account the mterms is to describe the radiation potentials $\phi _ { j }$ as a combination of a zero speed and a forward speed part:

$$
\phi_ {k} = \phi_ {k} ^ {0} - \frac {U}{i \omega_ {e}} \phi_ {k} ^ {U} \quad \forall k = 1, \dots , 6 \tag {14}
$$

By splitting the radiation potentials into zero speed and forward speed parts the body boundary condition in (12) can be split into two separate conditions:

$$
\begin{array}{l} \left. \frac {\partial \phi_ {k} ^ {0}}{\partial n} \right| _ {s _ {0}} = - i \omega_ {e} n _ {k} | _ {s _ {0}} \\ \left. \frac {\partial \phi_ {k} ^ {U}}{\partial n} \right| _ {s _ {0}} = - i \omega_ {e} m _ {k} | _ {s _ {0}} \quad \forall j = 1, \dots , 6 \end{array} \tag {15}
$$

This formulation which decomposes the radiation potentials into a zero speed $\phi _ { k } ^ { 0 }$ and a forward speed $\phi _ { k } ^ { U }$ part will always be used in the following. When the base flow is approximated by the uniform flow −????, a combination of (13) and (15) results in only two non-zero forward speed radiation potentials, which can be expressed as a function of the zero speed ones:

$$
\begin{array}{l} \phi_ {5} ^ {U} = \phi_ {3} ^ {0} \\ \phi_ {6} ^ {U} = - \phi_ {2} ^ {0} \end{array} \tag {16}
$$

# 2.4 PRESSURE CALCULATION

The pressure field is linked to the velocity field by the equations of momentum conservation. For a non-viscous and incompressible flow, these equations assume the form of the Euler equations. Integrating the Euler equations results in the Bernoulli equation for an unsteady flow:

$$
\frac {\partial \Phi}{\partial t} + \frac {1}{2} \nabla \Phi \cdot \nabla \Phi + \frac {p}{\rho} + g z = C \tag {17}
$$

where the time dependence of the constant ?? on the RHS has been moved to the potential Φ on the LHS. The total pressure can then be expressed as:

$$
p = - \rho \frac {\partial \Phi}{\partial t} - \frac {1}{2} \rho \nabla \Phi \cdot \nabla \Phi - \rho g z \tag {18}
$$

By substituting the potential terms obtained in section 2.3 one obtains:

$$
\begin{array}{r l} p = - \rho \frac {\partial \phi^ {\mathrm{UW}}}{\partial t} - \frac {1}{2} \rho \nabla (\phi^ {\mathrm{BF}} + \phi^ {\mathrm{SW}} + \phi^ {\mathrm{UW}}) \\ & \cdot \nabla (\phi^ {\mathrm{BF}} + \phi^ {\mathrm{SW}} + \phi^ {\mathrm{UW}}) - \rho g z \end{array} \tag {19}
$$

Under the assumption of a thin ship the base flow potential can be approximated by the uniform flow $\phi ^ { \mathrm { B F } } = - U x$ while under the assumption of a low speed the steady wave potential $\phi ^ { \mathsf { S W } }$ can be assumed to be zero. Under these two assumptions, (19) can be expanded and rewritten as:

$$
\begin{array}{l} p = - \rho \frac {\partial \phi^ {\mathrm{UW}}}{\partial t} - \frac {1}{2} \rho \left(U ^ {2} + \nabla \phi^ {\mathrm{UW}} \cdot \nabla \phi^ {\mathrm{UW}} \right. \tag {20} \\ - \left. 2 U \frac {\partial \phi^ {\mathrm{UW}}}{\partial x}\right) - \rho g z \\ \end{array}
$$

Plugging in (6) and re-arranging some terms the previous equation becomes:

$$
\begin{array}{l} p = \rho i \omega_ {e} \phi^ {\mathrm{UW}} e ^ {- i \omega_ {e} t} - \frac {1}{2} \rho U ^ {2} \\ - \frac {1}{2} \rho (\nabla \phi^ {\mathrm{UW}} \cdot \nabla \phi^ {\mathrm{UW}}) e ^ {- i \omega_ {e} t} (2 1) \\ + \rho U \frac {\partial \phi^ {\mathrm{UW}}}{\partial x} e ^ {- i \omega_ {e} t} - \rho g z \\ \end{array}
$$

The pressure can be split into a steady $p ^ { s }$ and an unsteady $\widetilde { p ^ { \mathrm { U } } }$ part:

$$
p ^ {S} = - \rho g z - \frac {1}{2} \rho U ^ {2} \tag {22}
$$

$$
\begin{array}{l} \widetilde {p ^ {\mathrm{U}}} = \rho i \omega_ {e} \phi^ {\mathrm{UW}} e ^ {- i \omega_ {e} t} \\ - \frac {1}{2} \rho (\nabla \phi^ {\mathrm{UW}} \cdot \nabla \phi^ {\mathrm{UW}}) e ^ {- i \omega_ {e} t} \tag {23} \\ + \rho U \frac {\partial \phi^ {\mathrm{UW}}}{\partial x} e ^ {- i \omega_ {e} t} \\ \end{array}
$$

As done for the unsteady wave potential (6), the unsteady pressure can be decomposed into a phasor and an oscillatory term:

$$
\widetilde {p ^ {\mathrm{U}}} = p ^ {\mathrm{U}} e ^ {- i \omega_ {e} t} \tag {24}
$$

The phasor of the unsteady pressure can be expressed as:

$$
\begin{array}{l} p ^ {\mathrm{U}} = \rho i \omega_ {e} \phi^ {\mathrm{UW}} - \frac {1}{2} \rho \left(\nabla \phi^ {\mathrm{UW}} \cdot \nabla \phi^ {\mathrm{UW}}\right) \tag {25} \\ + \rho U \frac {\partial \phi^ {\mathrm{UW}}}{\partial x} \\ \end{array}
$$

Finally, by considering only the terms which are linear in the phasor of the unsteady wave potential, the linearised phasor of the unsteady pressure can be expressed as:

$$
p ^ {\mathrm{UL}} = \rho i \omega_ {e} \phi^ {\mathrm{UW}} + \rho U \frac {\partial \phi^ {\mathrm{UW}}}{\partial x} \tag {26}
$$

# 2.5 FORCES AND HYDRODYNAMIC COEFFICIENTS

In the following, the concept of generalized forces will be used to define the set of three forces and three moments acting on a rigid body. The generalized forces can be expressed as a 6D vector:

$$
\vec {F} = \left[ F _ {1}, F _ {2}, F _ {3}, F _ {4}, F _ {5}, F _ {6} \right] = \left[ F _ {x}, F _ {y}, F _ {z}, M _ {x}, M _ {y}, M _ {z} \right] \tag {27}
$$

$$
\begin{array}{l} \text { where: } \quad F _ {x} = \text { surge   force } \\ F _ {y} = \text { sway   force } \\ F _ {z} = \text {   heave   force   } \\ M _ {x} = \text { roll   moment } \\ M _ {y} = \text { pitch   moment } \\ M _ {z} = \text { yaw   moment } \\ \end{array}
$$

If not otherwise specified, the term force will stand in the following text for one of the elements of the generalized forces vector, and will therefore indicate either a force $( j \ = \ 1 , 2 , 3 )$ or a moment $( j ~ = ~ 4 , 5 , 6 )$ .

# 2.5 (a) Generic hydrodynamic forces

A linear, frequency domain analysis of the forces acting on a freely floating body results in harmonic forces which oscillate at the encounter frequency $\omega _ { e }$ . As already seen for the unsteady wave potential (6) and for the unsteady pressure (24), the unsteady linear forces can be split into a phasor and an oscillatory term:

$$
\widetilde {F _ {j} ^ {\mathrm{UL}}} = F _ {j} ^ {\mathrm{UL}} e ^ {- i \omega_ {e} t} \quad \forall j = 1, \dots , 6 \tag {28}
$$

The focus of this section is an investigation of the phasor of the unsteady linear generalized forces $F _ { j } ^ { \mathrm { U L } }$ , which will be simply called $F _ { j }$ from now on for simplicity.

The phasor of the unsteady linear force which acts on a freely floating body, $F _ { j } .$ , can be calculated by integrating the phasor of the unsteady pressure $p ^ { \mathrm { U L } }$ over the hull surface. In a linear calculation, the integration is performed over the surface of the hull in its initial position in still water, $S _ { 0 } .$ . Therefore the phasor of unsteady linear forces can be calculated as:

$$
F _ {j} = - \iint_ {S _ {0}} n _ {j} p ^ {\mathrm{UL}} d s \tag {29}
$$

Substituting equation (26) into the above, the forces can be expressed as a function of the velocity potential and of the forward speed ??:

$$
F _ {j} = - \rho i \omega_ {e} \iint_ {S _ {0}} n _ {j} \phi^ {\mathrm{UW}} d s - \rho U \iint_ {S _ {0}} n _ {j} \frac {\partial \phi^ {\mathrm{UW}}}{\partial x} d s \tag {30}
$$

When dealing with a discretized hull, the mean surface of the hull $S _ { 0 }$ can be split into several panels. For each panel, the area, normal direction and position of the centroid can be calculated. The position of the centroid is used to query the potential field and its derivatives, and the potential (and its derivatives) are assumed to be constant over the panel. The generic force equation, (30), becomes:

$$
\begin{array}{l} F _ {j} = - \rho i \omega_ {e} \sum_ {p = 1} ^ {N} \left(n _ {p, j} \cdot \phi_ {p} ^ {\mathrm{UW}} \cdot a _ {p}\right) \tag {31} \\ - \rho U \sum_ {p = 1} ^ {N} \left(n _ {p, j} \cdot \frac {\partial \phi_ {p} ^ {\mathrm{UW}}}{\partial x} \cdot a _ {p}\right) \\ \end{array}
$$

where: ?? = panel index

$$
N = \text { total   number   of   panels }
$$

$$
a _ {p} \quad = \text {   area   of   panel   } p
$$

$$
n _ {p, j} = \text { generalized   normal   to   panel } p, \text { DOF } j
$$

$$
\phi_ {p} ^ {\mathrm{UW}} = \text { velocity   potential   on   panel } p
$$

The phasors of the total unsteady linear forces which act on a freely floating body can be calculated in a continuous (30) or discretized form (31). Such total forces are expressed as a function of the unsteady wave velocity potential and of its derivative in the ?? direction. According to decomposition of the steady wave potential (7) each of the 6 unsteady wave linear forces can be decomposed as well into an incident part, a diffraction part and 6 radiation parts. The part of an unsteady wave linear force which depends on the incident wave potential is also called Froude-Krylov force.

# 2.5 (b) Froude-Krylov Forces

The Froude-Krylov forces are the easiest to calculate: due to the fact that an analytical formulation of the incident wave potential exists (8), the Froude-Krylov forces can be calculated analytically without the need to solve a BVP. The phasor of the Froude-Krylov forces can be expressed, in the continuous form, as:

$$
F _ {j} ^ {\mathrm{FK}} = - \rho i \omega_ {e} \iint_ {S _ {0}} n _ {j} \phi_ {0} d s - \rho U \iint_ {S _ {0}} n _ {j} \frac {\partial \phi_ {0}}{\partial x} d s \tag {32}
$$

Considering the analytical formula for the incident potential, (8), the derivative of the incident potential in the x direction can be written as:

$$
\frac {\partial \phi_ {0}}{\partial x} = (i k \cos \mu) \cdot \phi_ {0} \tag {33}
$$

By merging (33) into (32) and re-arranging the terms, the Froude-Krylov forces can be expressed as:

$$
F _ {j} ^ {\mathrm{FK}} = - \rho i (\omega_ {e} + k U \cos \mu) \iint_ {S _ {0}} n _ {j} \phi_ {0} d s \tag {34}
$$

Inverting (3), the wave frequency ?? can be expressed as a function of the encounter frequency $\omega _ { e } .$

$$
\omega = \omega_ {e} + k U \cos \mu \tag {35}
$$

By using the previous equivalence, (34) can be simply rewritten as:

$$
F _ {j} ^ {\mathrm{FK}} = - \rho i \omega \iint_ {S _ {0}} n _ {j} \phi_ {0} d s \tag {36}
$$

This proves the somehow counterintuitive fact that the phasor of the Froude-Krylov force is exactly the same with or without a forward speed, and that it depends on the wave frequency ?? rather than on the encounter frequency $\omega _ { e }$ . This is only true for the phasor of the Froude-Krylov force. The full Froude-Krylov force however, like all other unsteady linear forces (28), is made up of the phasor and of an oscillatory term. The full Froude-Krylov force still oscillates, like all other forces, at the encounter frequency:

$$
\widetilde {F _ {j} ^ {\mathrm{FK}}} = F _ {j} ^ {\mathrm{FK}} e ^ {- i \omega_ {e} t} \quad \forall j = 1, \dots , 6 \tag {37}
$$

# 2.5 (c) Diffraction Forces

In order to calculate the diffraction forces, a BVP needs to be solved. The solution of the BVP is based on imposing the body boundary condition (10). In order to solve the BVP with a forward speed, the incident wave potential should be calculated for the wave frequency ??, as one can intuitively guess since the incident waves are not influenced by the ship’s speed. On the other hand, the Green’s functions required to solve the BVP, which essentially represent sources of the unknown diffraction potential $\phi _ { 7 }$ , need to be calculated for the encounter frequency $\omega _ { e }$ .

Once the BVP is solved and the diffraction potential is obtained, the phasor of the diffraction forces can be calculated as:

$$
F _ {j} ^ {\mathrm{D}} = - \rho i \omega_ {e} \iint_ {S _ {0}} n _ {j} \phi_ {7} d s - \rho U \iint_ {S _ {0}} n _ {j} \frac {\partial \phi_ {7}}{\partial x} d s \tag {38}
$$

The first integral in the equation above is the diffraction force experienced by the body when it has a zero speed, while the second integral can be intended as a correction to the zero-speed diffraction force due to the forward speed of the body.

# 2.5 (d) Radiation Forces

Radiation forces are slightly more complex than the Froude-Krylov and diffraction forces. The radiation forces are the forces which act on the body due to the fact that the body oscillates in one of the 6 DOF. Each oscillation mode can in general generate forces in each of the 6 DOF. Therefore, there are 36 radiation forces resulting from the combination of the body oscillations with the direction in which the originated forces act. In order to calculate the radiation forces, six BVPs need to be solved, one for each DOF in which the body is forced to oscillate harmonically. The solution of the BVPs is based on imposing the body boundary conditions (11).

Once the BVPs are solved and the radiation potentials $\phi _ { k }$ are obtained, the phasor of the radiation forces can be calculated as:

$$
F _ {j k} ^ {\mathrm{R}} = - \rho i \omega_ {e} \iint_ {S _ {0}} n _ {j} \phi_ {k} d s - \rho U \iint_ {S _ {0}} n _ {j} \frac {\partial \phi_ {k}}{\partial x} d s \tag {39}
$$

The double indexing of the radiation forces is due to what described above, with the first index ?? representing the force direction and the second index ?? representing the motion mode. As stated in equation (14), the radiation potentials can be expressed as the sum of a zero speed part and a speed dependent part. When the base flow is approximated by the uniform flow −????, the speed dependent part of the radiation potentials can be expressed as a function of the zero speed potentials (14). When this representation for the radiation potentials is adopted, the phasor of the radiation forces can be rewritten as:

$$
\begin{array}{l} F _ {j k} ^ {\mathrm{R}} = - \rho i \omega_ {e} \iint_ {S _ {0}} n _ {j} \phi_ {k} ^ {0} d s + \rho U \iint_ {S _ {0}} n _ {j} \phi_ {k} ^ {U} d s \\ - \rho U \iint_ {S _ {0}} n _ {j} \frac {\partial \phi_ {k} ^ {0}}{\partial x} d s \tag {40} \\ + \rho \frac {U ^ {2}}{i \omega_ {e}} \iint_ {S _ {0}} n _ {j} \frac {\partial \phi_ {k} ^ {U}}{\partial x} d s \\ \end{array}
$$

Equation (40) is the sum of four integrals: the first integral is the only one which is present when the body has a zero speed. The remaining three integrals can be intended as a correction to the zero-speed radiation forces. The four integrals can be named for convenience as:

$$
\begin{array}{l} F _ {j k} ^ {\mathrm{R0}} = - \rho i \omega_ {e} \iint_ {S _ {0}} n _ {j} \phi_ {k} ^ {0} d s \\ F _ {j k} ^ {\mathrm{RU0}} = \rho U \iint_ {S _ {0}} n _ {j} \phi_ {k} ^ {U} d s (41) \\ F _ {j k} ^ {\mathrm{RU1}} = - \rho U \iint_ {S _ {0}} n _ {j} \frac {\partial \phi_ {k} ^ {0}}{\partial x} d s (41) \\ F _ {j k} ^ {\mathrm{RU2}} = \rho \frac {U ^ {2}}{i \omega_ {e}} \iint_ {S _ {0}} n _ {j} \frac {\partial \phi_ {k} ^ {U}}{\partial x} d s \\ \end{array}
$$

where $F _ { j k } ^ { { \mathrm R } 0 }$ is the zero-speed radiation force and the remaining three terms are the corrections due to forward speed.

When the base flow is approximated by the uniform flow −????, only two forward speed radiation potentials $\Phi _ { k } ^ { U }$ are non-zero, as shown in equation (16).

2.5 (e) Radiation Forces with respect to a Unit Velocity

The radiation forces determined in the previous section are based on the radiation potentials, which are the output of potential seakeeping solvers. The radiation potentials considered so far in this document are the ones obtained when solving the radiation BVP by imposing a unit motion amplitude to the body. Actually, many potential solvers (like HydroStar and Capytaine) impose instead a unit velocity amplitude when solving the radiation BVP. Since the generic harmonic motion of the body in the k-th DOF can be expressed as $\tilde { \xi } _ { k } = \xi _ { k } e ^ { - i \omega _ { e } t }$ , the harmonic velocity of the body can be expressed as:

$$
\dot {\tilde {\xi}} _ {k} = - i \omega_ {e} \xi_ {k} e ^ {- i \omega_ {e} t} = \dot {\xi} _ {k} e ^ {- i \omega_ {e} t} \tag {42}
$$

where $\dot { \xi } _ { k }$ is the velocity amplitude, which is linked to the motion amplitude by $\dot { \xi } _ { k } = - i \omega _ { e } \xi _ { k }$ . When the body moves with a unit velocity amplitude, $\dot { \xi } _ { k } = 1$ , the motion amplitude is $\xi _ { k } = 1 / ( - i \omega _ { e } )$ . Therefore, due to the assumptions of linearity, all the derived quantities calculated for a unit velocity will $\mathbf { b e } - i \omega _ { e }$ times smaller than the ones calculated for a unit motion. The previously defined radiation potentials due to a unit motion amplitude, $\phi _ { k }$ , can be expressed as a function of the radiation potentials due to a unit velocity amplitude:

$$
\phi_ {k} = - i \omega_ {e} \phi_ {k} ^ {V} \tag {43}
$$

The same applies to the relation between the radiation force due to a unit motion and the one due to a unit velocity:

$$
F _ {j k} ^ {\mathrm{R}} = - i \omega_ {e} F _ {j k} ^ {\mathrm{RV}} \tag {44}
$$

# 2.5 (f) Radiation Hydrodynamic Coefficients

The radiation forces are usually expressed in terms of a component in phase with the acceleration of the body, called added mass, and a component in phase with the velocity of the body which is called radiation damping. The set of these two terms is usually referred to as the radiation hydrodynamic coefficients.

The added mass $A _ { j k }$ and damping $B _ { j k }$ coefficients can be calculated from the radiation forces $F _ { j k } ^ { \mathrm { R } }$ according to:

$$
\begin{array}{l} \begin{array}{l} A _ {j k} = - \Re \left(F _ {j k} ^ {\mathrm{R}}\right) / \omega_ {e} ^ {2} \\ R = \approx \left(E ^ {\mathrm{R}}\right) / \end{array} \tag {45} \\ B _ {j k} = - \Im \big (F _ {j k} ^ {\mathrm{R}} \big) / \omega_ {e} \\ \end{array}
$$

The equations above can be applied to the total radiation forces $F _ { j k } ^ { \mathrm { R } }$ as well as to any of the four terms in equation (41). When dealing with radiation forces due to a unit velocity of the body, the added mass and damping can be calculated by plugging (44) into (45):

$$
\begin{array}{l} A _ {j k} = \Im \left(F _ {j k} ^ {\mathrm{RV}}\right) / \omega_ {e} \tag {46} \\ B _ {j k} = - \Re \left(F _ {j k} ^ {\mathrm{RV}}\right) \\ \end{array}
$$

# 3 METHODOLOGY

# 3.1 CAPYTAINE IMPLEMENTATION

In order to account for forward speed effects according to the AFS method, the code of Capytaine had to be altered. The main modifications encompassed the use of the encounter wave frequency for the Green’s functions needed to solve the BVPs and the calculation of the ?? derivatives of the potential along the mesh, which is not a standard Capytaine output. Both modifications are described in more detail below.

# 3.1 (a) Green’s functions and boundary conditions

The AFS method is based on the use of zero speed Green’s functions to solve the BVPs and on correcting the results according to the formulation described in chapter 2. However, since the ship will always oscillate at the encounter frequency, the Green’s functions to be used should be the ones associated with the encounter frequency rather than the wave frequency. In Capytaine this is slightly complicated by the fact that the Green’s functions are defined as a function of the wave number ?? rather than of the wave frequency. Therefore, in order to properly define the Green’s functions for forward speed problems, a fake wave number has to be defined, even if the forward speed does not actually change the wave length and therefore the wave number. The fake wave number $k _ { e }$ is the wave number that would correspond to the encounter frequency $\omega _ { e }$ if such frequency was actually wave frequency. The fake wave number can be obtained by inverting the dispersion relation, equation (2). Green’s functions used when solving BVPs for forward speed are always the ones associated with the fake wave number as a function of the encounter frequency, which in turn depends on the wave frequency and the forward speed: $G = G \big ( k _ { e } ( \omega _ { e } ) \big )$ .

For the radiation problems, the body boundary conditions require the body motions as the RHS, see equation (11). No additional treatments are required to solve the radiation BVPs for forward speed according to the AFS method other than considering the Green’s functions associated with the encounter frequency (or the fake wave number). For the diffraction problem, on the other hand, the RHS of the body boundary condition, equation (10), is the incident wave potential defined in equation (8). Special care has to be put in ensuring that the wave angular frequency ?? and the wave number ?? which appear in the incident wave potential are actually the wave ones and not the encounter frequency or the fake wave number used to define the Green’s functions.

# 3.1 (b) Derivatives of the potentials

The AFS method needs the ?? derivative of the potentials on the mesh panels as stated in the generic force equation (31). Unfortunately, Capytaine does not provide a method to directly retrieve the directional derivatives of the potential along one of the three main coordinates.

However, an auxiliary mesh can be defined in Capytaine and the normal derivatives of the potential with respect to this auxiliary mesh can be calculated and outputted. In order to obtain the ?? derivatives of potentials required by the AFS method, the auxiliary mesh was defined in a clever way: a mesh with panels centered on the centroids of the hull mesh and all lying in the ???? plane, as shown in Figure 1.

![](images/12e37b4cd4c617fbf6736db2bde19ac02d2551f107fcee05addec8d730dc0dd6.jpg)

<details>
<summary>surface_3d</summary>

| x  | y    |
|----|------|
| 0  | 0    |
| 50 | 0    |
| 100| 0    |
| 150| 0    |
| 200| 0    |
</details>

Figure 1. The auxiliary mesh used to retrieve the x derivatives of the potential.

The size of the auxiliary mesh’s panels is irrelevant. By defining the auxiliary mesh in this way, Capytaine can be used to retrieve the normal derivatives of potential on the auxiliary mesh’s panels. This is done by first calling Capytaine’s inner function to calculate the influence matrices for an auxiliary panel ??. The influence matrices $\pmb { S } _ { a p }$ and $\pmb { V } _ { a p }$ use respectively the Green’s functions and their gradient to express the effects that the sources ?? distributed on the hull mesh panels ?? induce on the auxiliary panel ?? (Ancellin and Dias, 2019; Babarit and Delhommeau, 2015). The following relations can be used to calculate the normal derivatives of the potential on the auxiliary panel (Ancellin and Dias, 2019):

$$
\phi_ {a} = \boldsymbol {S} _ {a p} \boldsymbol {\sigma} \tag {47}
$$

$$
\frac {\partial \phi_ {a}}{\partial n} = \left(\frac {\mathbf {I}}{2} + V _ {a p}\right) \boldsymbol {\sigma} \tag {48}
$$

The array of sources ?? is calculated and stored when Capytaine solves the BVPs as outlined in section 3.1 (a). Then, the velocity which corresponds to the location of the auxiliary panel ?? can be calculated using equation (48). This process is repeated for all the auxiliary panels in order to obtain the potential derivatives around the whole hull mesh.

Since the auxiliary panels are all on the ???? plane, the normal direction to the panels is actually the ?? direction, and the normal derivative of the potential is actually the ?? derivative of interest. Moreover, since the centroids of the auxiliary mesh correspond to the centroids of the hull’s mesh, the derivatives are the ones corresponding to the hull panels which can be used in equation (31).

# 3.2 KCS SHIP

The KRISO Container Ship (KCS), also called MOERI Container Ship, is a benchmark hull shape introduced in 1997 to facilitate comparisons of numerical methods for the solution of the hydrodynamic problems of seakeeping and manoeuvring. Tests on scale models of the KCS ship were performed at several research institutes around the world. Several papers describing seakeeping results for this hull shape exist in literature, among others (Hasnan et al., 2020; Simonsen et al., 2013; Stocker, 2016). The KCS ship is recurrently used as one of the benchmark ship in the SIMMAN workshops about the validation of ship manoeuvring simulation methods. All the information about the KCS hull form and a 3D file with its geometry can be found on (SIMMAN 2008, n.d.).

The hull shape of the KCS, up to the design draft of 10.8 m, was meshed with triangular and quadrangular panels with the mesh generator of HydroStar. The mesh generator was set up to produce a mesh made of 2562 panels. This discretized version of the KCS hull shape was used in all the simulations performed to write this paper.

# 3.3 CODE VALIDATION

The modified version of Capytaine which includes forward speed according to the AFS method was used to solve the radiation and diffraction BVPs for the KCS ship described in 3.2. Simulations were performed for zero forward speed and for a forward speed of 10 knots. A single heading of 180 degrees (head waves) was investigated in this preliminary work in order to assess the correctness of the implementation. Infinite water depth was assumed, but since Capytaine, which is derived from Nemoh, is already capable of dealing with shallow water effects (Gourlay et al., 2019), the inclusion of forward speed effects is expected to be fully valid in shallow water conditions as well. Other ships, headings, water depths and speeds will be tested and published in the future.

The same simulations using the exact same input mesh were performed using the commercial code HydroStar. The results obtained with the modified version of Capytaine are compared with the results from HydroStar in the next chapter.

# 3.4 REFERENCE SYSTEMS AND CONVENTIONS

In order to compare the results of the two codes, the different conventions adopted in each of the codes had to be properly accounted by converting the results to a common reference. The HydroStar conventions were selected as the common reference and the results from Capytaine were converted to match the HydroStar conventions in the following. The different conventions between the two codes are briefly described in this section.

# 3.4 (a) Reference wave

First of all, HydroStar represents the reference wave in a slightly different way than Capytaine. The signs of the exponential terms for time and space dependence in equation (4) are reversed in HydroStar, resulting for example in the following expression for the wave elevation:

$$
\zeta (x, y, t) = \Re \bigl (\zeta_ {\mathrm{A}} e ^ {- i k (x \cos (\mu) + y \sin (\mu))} e ^ {i \omega_ {e} t} e ^ {i \varepsilon} \bigr) \qquad (4 9)
$$

This different convention on how to represent wave related parameters slightly alters all the formulation described in chapter 2, affecting the signs of several terms. The entire theoretical approach is not re-written here for brevity. The most important changes from the practical point of view are in the equations for the diffraction and radiation forces, (38) and (40), which become respectively:

$$
F _ {j} ^ {\mathrm{D}} = \rho i \omega_ {e} \iint_ {S _ {0}} n _ {j} \phi_ {7} d s - \rho U \iint_ {S _ {0}} n _ {j} \frac {\partial \phi_ {7}}{\partial x} d s \tag {50}
$$

$$
\begin{array}{l} F _ {j k} ^ {\mathrm{R}} = \rho i \omega_ {e} \iint_ {S _ {0}} n _ {j} \phi_ {k} ^ {0} d s + \rho U \iint_ {S _ {0}} n _ {j} \phi_ {k} ^ {U} d s \\ - \rho U \iint_ {S _ {0}} n _ {j} \frac {\partial \phi_ {k} ^ {0}}{\partial x} d s \tag {51} \\ - \rho \frac {U ^ {2}}{i \omega_ {e}} \iint_ {S _ {0}} n _ {j} \frac {\partial \phi_ {k} ^ {U}}{\partial x} d s \\ \end{array}
$$

Therefore, when calculating the diffraction forces and the radiation coefficients starting from HydroStar potentials and derivatives, equations (50) and (51) should be used, rather than their equivalent forms valid for Capytaine results, equations (38) and (40).

# 3.4 (b) Phases conventions

Other relevant differences in the set of conventions adopted in the two codes are related to the phases of the calculated potentials, and therefore also of the potential derivatives and of the total diffraction forces and total radiation coefficients. A first, straightforward difference is that HydroStar provides phases as a phase lead with respect to the relevant parameter, while Capytaine outputs the phase lag. In order to correctly compare the results, the phases from Capytaine were therefore taken with the opposite sign in the following.

Finally, while the phase of radiation potentials is expressed with respect to the relevant ship’s motion, the phase of the diffraction potentials is expressed with respect to the incident waves. The phase of the incident waves should also be defined, and that is usually done by means of a wave reference point: a parameter which defines the position on the horizontal plane of the point where the wave elevation reaches a maximum (crest) at ?? = 0. While the wave reference point is set by default as the center of buoyancy (CoB) in HydroStar, it is set to the point with coordinates (0,0,0) in Capytaine. This phase difference can be simply compensated by multiplying the potentials (and their derivatives) from Capytaine by the complex exponential term:

$$
e ^ {i k \left(x _ {C O B} \cos \mu + y _ {C O B} \sin \mu\right)} \tag {52}
$$

$\begin{array} { r l r } { \mathrm { w h e r e } ; ~ k } & { { } \ } & { = { } \ \mathrm { w a v e n u m b e r } } \end{array}$

$$
\mu = \text { incident   angle   of   the   waves }
$$

$$
x _ {C O B} = \text { CoB } x \text { coordinate   wrt } (0, 0, 0)
$$

$$
y _ {C O B} = \text { CoB   } y \text {   coordinate   wrt   } (0, 0, 0)
$$

# 4 RESULTS

The core results of a 3D panel code come from the solution of the diffraction problem and of the 6 radiation problems. The solution of these BVPs produces six complex diffraction forces and 36 complex radiation forces. The complex radiation forces are usually split into two radiation coefficients, added mass and damping, as detailed in 2.5 (f). The RAOs for oscillatory motions can be obtained once the diffraction and radiation forces are calculated by solving a linear system which describes the frequency domain equations of motion in 6 DOF. In this paper, motion RAOs will not be investigated, since they can be considered as a post-processing of the complex radiation and diffraction forces which result from the solution of the BVPs.

The radiation coefficients and the complex diffraction forces obtained with the modified version of Capytaine and with HydroStar are compared in this chapter for both zero speed and a forward speed of 10 knots. The results for a single incident wave angle of 180 degrees (head waves) are presented, focusing on the three longitudinal degrees of freedom (surge, heave, pitch).

The comparison of the results outlined a good agreement for both the radiation coefficients and the diffraction forces, confirming that the AFS method is implemented correctly in Capytaine. The results of Capytaine are still affected by numerical instabilities at high frequencies. The reason for these numerical instabilities might be linked with the effects of irregular frequencies, but the extension of the erratic behaviour over a wide range of frequencies seems to suggest otherwise. Further research is needed to explore the issue in greater detail. The effects of irregular frequencies are damped in HydroStar by using the fake lid approach (Malenica and Chen, 1998), which has not been implemented in Capytaine yet. The erratic behaviour of Capytaine at high encounter frequencies seems to be unrelated with the forward speed implementation, since the same instabilities were noticed also for zero speed conditions, at higher frequencies. Therefore, such instabilities do not hinder the results published in this paper.

# 4.1 RADIATION COEFFICIENTS

The results for the radiation coefficients of added mass and damping showed in general a very good agreement between the modified version of Capytaine and HydroStar, as shown in Figure 2 to Figure 10. The main trends are well captured in all cases, for both diagonal and cross terms. The only small discrepancy that can be observed is a sort of offset between the results of Capytaine and those of HydroStar which can be noticed for terms 13 (Figure 3) and 53 (Figure 9). The same offset is also observed in the same coefficients for the zero speed case and as such cannot be ascribed to the present implementation of forward speed effects.

![](images/6f620bf84d2d6293a79822449e7ef13dd6f84021fa47a638c5bb37cab6d78f43.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | HyS 0kn | Cap 0kn | HyS 10kn | Cap 10kn |
| --------- | ------- | ------- | -------- | -------- |
| 0.0       | ~1.8e6  | ~1.7e6  | ~1.8e6   | ~1.7e6   |
| 0.2       | ~2.1e6  | ~2.0e6  | ~2.1e6   | ~2.0e6   |
| 0.4       | ~2.3e6  | ~2.2e6  | ~2.3e6   | ~2.2e6   |
| 0.6       | ~1.5e6  | ~1.4e6  | ~1.5e6   | ~1.4e6   |
| 0.8       | ~0.8e6  | ~0.7e6  | ~0.8e6   | ~0.7e6   |
| 1.0       | ~0.6e6  | ~0.5e6  | ~0.6e6   | ~0.5e6   |
| 1.2       | ~0.5e6  | ~0.4e6  | ~0.5e6   | ~0.4e6   |
</details>

![](images/e410bda406ad182e0cb9d19195667032ce6650871d7d0eec903a5797de174864.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | Damping [kg/s] (solid line) | Damping [kg/s] (dashed line) | Damping [kg/s] (black line) |
| --------- | --------------------------- | ---------------------------- | --------------------------- |
| 0.0       | 0                           | 0                            | 0                           |
| 0.2       | ~0                          | ~0                           | ~0                          |
| 0.4       | ~7×10⁵                      | ~5×10⁵                       | ~7×10⁵                      |
| 0.6       | ~7.5×10⁵                    | ~7×10⁵                       | ~7×10⁵                      |
| 0.8       | ~6.5×10⁵                    | ~6.5×10⁵                     | ~6×10⁵                      |
| 1.0       | ~5.5×10⁵                    | ~6×10⁵                       | ~5×10⁵                      |
| 1.2       | ~3.5×10⁵                    | ~6×10⁵                       | ~3.5×10⁵                    |
</details>

Figure 2. Radiation coefficients for term 11.

![](images/8fdacce702fe82a1138308cfe816709ff1e470f9f2162b469000501012ad2bfc.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | HyS 0kn | Cap 0kn | HyS 10kn | Cap 10kn |
| --------- | ------- | ------- | -------- | -------- |
| 0.0       | 2.0e6   | 2.0e6   | 2.0e6    | 1.5e6    |
| 0.2       | 2.2e6   | 2.1e6   | 2.3e6    | 2.0e6    |
| 0.4       | 2.5e6   | 2.4e6   | 3.0e6    | 2.9e6    |
| 0.6       | 2.3e6   | 2.2e6   | 2.5e6    | 2.4e6    |
| 0.8       | 2.0e6   | 1.9e6   | 1.8e6    | 1.7e6    |
| 1.0       | 1.8e6   | 1.7e6   | 1.6e6    | 1.5e6    |
| 1.2       | 1.5e6   | 1.4e6   | 1.3e6    | 1.2e6    |
</details>

![](images/631a458e87268d1c386c4f4a2f368f351bb1805a78d9ccd7089f6e3c8e97ec6a.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | Damping [kg/s] (×10⁵) |
| --------- | ---------------------- |
| 0.0       | -8.0                   |
| 0.2       | -9.0                   |
| 0.4       | -3.0                   |
| 0.6       | -2.0                   |
| 0.8       | -12.0                  |
| 1.0       | -4.0                   |
| 1.2       | -5.0                   |
</details>

Figure 3. Radiation coefficients for term 13.

![](images/9a9e8e904f695776d0c1a7dc4a102cff3cd9fc27509868a5f6c065f82a9cf379.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | HyS 0kn | Cap 0kn | HyS 10kn | Cap 10kn |
| --------- | ------- | ------- | -------- | -------- |
| 0.0       | ~10^9   | ~10^9   | ~10^9    | ~10^9    |
| 0.2       | ~10^9   | ~10^9   | ~10^9    | ~10^9    |
| 0.4       | ~10^9   | ~10^9   | ~10^9    | ~10^9    |
| 0.6       | ~10^9   | ~10^9   | ~10^9    | ~10^9    |
| 0.8       | ~10^9   | ~10^9   | ~10^9    | ~10^9    |
| 1.0       | ~10^9   | ~10^9   | ~10^9    | ~10^9    |
| 1.2       | ~10^9   | ~10^9   | ~10^9    | ~10^9    |
</details>

![](images/d2c44812f1da54888ff5b65658cee06dd7a1761e72841203df74558c0c94b3c6.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | Damping [kg·m/s] (Solid Black) | Damping [kg·m/s] (Dashed Red) | Damping [kg·m/s] (Dotted Black) |
| --------- | ------------------------------ | ----------------------------- | ------------------------------- |
| 0.0       | 0                              | 0                             | 0                               |
| 0.2       | ~0.5×10⁸                       | ~0.3×10⁸                      | ~0.2×10⁸                        |
| 0.4       | ~2.8×10⁸                       | ~2.7×10⁸                      | ~2.6×10⁸                        |
| 0.6       | ~2.6×10⁸                       | ~2.5×10⁸                      | ~2.4×10⁸                        |
| 0.8       | ~2.0×10⁸                       | ~1.9×10⁸                      | ~1.8×10⁸                        |
| 1.0       | ~1.5×10⁸                       | ~1.4×10⁸                      | ~1.3×10⁸                        |
| 1.2       | ~1.0×10⁸                       | ~1.0×10⁸                      | ~1.0×10⁸                        |
</details>

Figure 4. Radiation coefficients for term 15.

![](images/38ca1d16e733acba2c967a1d492b0dd30491d2ef699a0cb4f8837158dbb4a554.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | HyS 0kn | Cap 0kn | HyS 10kn | Cap 10kn |
| --------- | ------- | ------- | -------- | -------- |
| 0.0       | 2.0e6   | 2.0e6   | 2.0e6    | 1.5e6    |
| 0.2       | 2.0e6   | 2.0e6   | 2.0e6    | 2.0e6    |
| 0.4       | 2.5e6   | 2.5e6   | 0.7e6    | 0.7e6    |
| 0.6       | 2.0e6   | 2.0e6   | 1.0e6    | 1.0e6    |
| 0.8       | 1.8e6   | 1.8e6   | 1.2e6    | 1.2e6    |
| 1.0       | 1.7e6   | 1.7e6   | 1.3e6    | 1.3e6    |
| 1.2       | 1.6e6   | 1.6e6   | 1.4e6    | 1.4e6    |
</details>

![](images/36e7158948824798dbb87737dbeeb5a9a00a35b1009e634fd7d334c5e48ab607.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | Damping [kg/s] (×10⁵) |
| --------- | ---------------------- |
| 0.0       | 4.0                    |
| 0.2       | 6.0                    |
| 0.4       | 7.5                    |
| 0.6       | 3.5                    |
| 0.8       | 2.5                    |
| 1.0       | 1.5                    |
| 1.2       | 1.0                    |
</details>

Figure 5. Radiation coefficients for term 31.

![](images/7fb35fce714bd46f40286c0dc7bd28b9cb286f8714498a48fd3466aff618420c.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | HyS 0kn | Cap 0kn | HyS 10kn | Cap 10kn |
| --------- | ------- | ------- | -------- | -------- |
| 0.0       | 16.0e7  | 16.0e7  | 16.0e7   | 16.0e7   |
| 0.2       | 17.0e7  | 17.0e7  | 17.0e7   | 17.0e7   |
| 0.4       | 10.0e7  | 10.0e7  | 10.0e7   | 10.0e7   |
| 0.6       | 6.0e7   | 6.0e7   | 6.0e7    | 6.0e7    |
| 0.8       | 5.5e7   | 5.5e7   | 5.5e7    | 5.5e7    |
| 1.0       | 5.5e7   | 5.5e7   | 5.5e7    | 5.5e7    |
| 1.2       | 5.5e7   | 5.5e7   | 5.5e7    | 5.5e7    |
</details>

![](images/b305fb711abab13c6eee14e553a0c2f89a153b75d9a264bdb1d0e7aa74927cf2.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | Damping [kg/s] (Solid Line) | Damping [kg/s] (Dashed Line) |
| --------- | --------------------------- | ---------------------------- |
| 0.0       | 0                           | 0                            |
| 0.2       | ~1.5×10⁷                    | ~1.8×10⁷                     |
| 0.4       | ~3.7×10⁷                    | ~3.8×10⁷                     |
| 0.6       | ~3.0×10⁷                    | ~3.5×10⁷                     |
| 0.8       | ~1.5×10⁷                    | ~2.5×10⁷                     |
| 1.0       | ~1.0×10⁷                    | ~2.0×10⁷                     |
| 1.2       | ~0.5×10⁷                    | ~1.5×10⁷                     |
</details>

Figure 6. Radiation coefficients for term 33.

![](images/36f579ff658b1dfabc331af6b7c54b49baef47896e173313e1c5f05995459818.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | HyS 0kn | Cap 0kn | HyS 10kn | Cap 10kn |
| --------- | ------- | ------- | -------- | -------- |
| 0.0       | 8.0e9   | 1.0e9   | 8.0e9    | 8.0e9    |
| 0.2       | 2.0e9   | 1.5e9   | 1.0e9    | 1.5e9    |
| 0.4       | 1.5e9   | 1.0e9   | 0.5e9    | 1.0e9    |
| 0.6       | 1.0e9   | 0.8e9   | 0.3e9    | 0.8e9    |
| 0.8       | 0.8e9   | 0.6e9   | 0.2e9    | 0.6e9    |
| 1.0       | 0.6e9   | 0.5e9   | 0.1e9    | 0.5e9    |
| 1.2       | 0.5e9   | 0.4e9   | 0.1e9    | 0.4e9    |
</details>

![](images/4ecd9edf37bfe0c761bfb3f8f0a9558cd3273797c2bba8fca4392a991625defb.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | Damping [kg·m/s] (Solid Black) | Damping [kg·m/s] (Solid Red) | Damping [kg·m/s] (Dashed Red) |
| --------- | ------------------------------ | ---------------------------- | ----------------------------- |
| 0.0       | ~10×10⁸                        | ~10×10⁸                      | 0                             |
| 0.2       | ~11×10⁸                        | ~11×10⁸                      | ~1×10⁸                        |
| 0.4       | ~9×10⁸                         | ~8×10⁸                       | ~3×10⁸                        |
| 0.6       | ~7×10⁸                         | ~7×10⁸                       | ~4×10⁸                        |
| 0.8       | ~6×10⁸                         | ~2×10⁸                       | ~4×10⁸                        |
| 1.0       | ~6×10⁸                         | ~6×10⁸                       | ~4×10⁸                        |
| 1.2       | ~6×10⁸                         | ~6×10⁸                       | ~4×10⁸                        |
</details>

Figure 7. Radiation coefficients for term 35.

![](images/012501c8ce7f8fe821744578e56a23b055dfd21651dd196e2df39d9c7b49fcb5.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | HyS 0kn | Cap 0kn | HyS 10kn | Cap 10kn |
| --------- | ------- | ------- | -------- | -------- |
| 0.0       | 6.5e8   | 6.5e8   | 6.5e8    | 5.5e8    |
| 0.2       | 7.5e8   | 7.5e8   | 7.5e8    | 7.5e8    |
| 0.4       | 8.0e8   | 8.0e8   | 8.0e8    | 8.0e8    |
| 0.6       | 6.0e8   | 6.0e8   | 6.0e8    | 6.0e8    |
| 0.8       | 3.0e8   | 3.0e8   | 3.0e8    | 3.0e8    |
| 1.0       | 2.5e8   | 2.5e8   | 2.5e8    | 2.5e8    |
| 1.2       | 2.5e8   | 2.5e8   | 2.5e8    | 2.5e8    |
</details>

![](images/cad5fd7e2ba5c6a897cf1e7e557c62cd47c299d48e8f44af96e4b3786aa54733.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | Damping [kg·m/s] (Solid Line) | Damping [kg·m/s] (Dashed Line) | Damping [kg·m/s] (Dotted Line) |
| --------- | ----------------------------- | ------------------------------ | ------------------------------ |
| 0.0       | 0                             | 0                              | 0                              |
| 0.2       | ~0                            | ~0                             | ~0                             |
| 0.4       | ~2.5×10⁸                      | ~2.5×10⁸                       | ~2.5×10⁸                       |
| 0.6       | ~2.3×10⁸                      | ~2.7×10⁸                       | ~2.5×10⁸                       |
| 0.8       | ~1.8×10⁸                      | ~2.2×10⁸                       | ~2.0×10⁸                       |
| 1.0       | ~1.2×10⁸                      | ~1.8×10⁸                       | ~1.5×10⁸                       |
| 1.2       | ~0.8×10⁸                      | ~1.5×10⁸                       | ~1.2×10⁸                       |
</details>

Figure 8. Radiation coefficients for term 51.

![](images/657f0dc6719825a5c866cbea74ff24ee12c9bcddca617b5a856c1ddc3b8df592.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | HyS 0kn | Cap 0kn | HyS 10kn | Cap 10kn |
| --------- | ------- | ------- | -------- | -------- |
| 0.0       | 1.9e9   | 1.9e9   | 1.9e9    | 1.9e9    |
| 0.2       | 2.0e9   | 1.9e9   | 2.0e9    | 1.9e9    |
| 0.4       | 1.5e9   | 1.4e9   | 1.5e9    | 1.4e9    |
| 0.6       | 1.0e9   | 0.9e9   | 1.0e9    | 0.9e9    |
| 0.8       | 0.7e9   | 0.6e9   | 0.7e9    | 0.6e9    |
| 1.0       | 0.6e9   | 0.5e9   | 0.6e9    | 0.5e9    |
| 1.2       | 0.5e9   | 0.5e9   | 0.5e9    | 0.5e9    |
</details>

![](images/97fa4f64688e287beb5b79ef17c724abdb0e066868ce398de0682f2b958e773f.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | Damping [kg·m/s] (Solid Black) | Damping [kg·m/s] (Dashed Red) | Damping [kg·m/s] (Dotted Black) |
| --------- | ------------------------------ | ----------------------------- | ------------------------------- |
| 0.0       | -2.0e8                         | 0.0e8                         | -2.0e8                          |
| 0.2       | -1.0e8                         | 1.0e8                         | -1.0e8                          |
| 0.4       | 1.5e8                          | 3.0e8                         | 1.5e8                           |
| 0.6       | 1.8e8                          | 4.0e8                         | 1.8e8                           |
| 0.8       | 1.5e8                          | 4.0e8                         | 1.5e8                           |
| 1.0       | 1.0e8                          | 4.0e8                         | 1.0e8                           |
| 1.2       | 0.5e8                          | 4.0e8                         | 0.5e8                           |
</details>

Figure 9. Radiation coefficients for term 53.

![](images/e28bde808c09a1d71718d9c7937575aef9bdb2eefa554062e8e4ea503cd828cb.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | HyS 0kn | Cap 0kn | HyS 10kn | Cap 10kn |
| --------- | ------- | ------- | -------- | -------- |
| 0.0       | ~4.5e12 | ~4.5e12 | ~4.5e12  | ~4.5e12  |
| 0.2       | ~0.5e12 | ~0.5e12 | ~0.5e12  | ~0.5e12  |
| 0.4       | ~0.3e12 | ~0.3e12 | ~0.3e12  | ~0.3e12  |
| 0.6       | ~0.2e12 | ~0.2e12 | ~0.2e12  | ~0.2e12  |
| 0.8       | ~0.1e12 | ~0.1e12 | ~0.1e12  | ~0.1e12  |
| 1.0       | ~0.05e12| ~0.05e12| ~0.05e12 | ~0.05e12 |
| 1.2       | ~0.02e12| ~0.02e12| ~0.02e12 | ~0.02e12 |
</details>

![](images/fc0b46a09add2ea3d1c64250930e5b585bdc87006d8166b3f84757071c16f20c.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | Damping [×10¹⁰ kg·m²/s] |
| --------- | ------------------------ |
| 0.0       | 0.0                      |
| 0.2       | 0.0                      |
| 0.4       | 10.0                     |
| 0.6       | 10.0                     |
| 0.8       | 7.0                      |
| 1.0       | 5.0                      |
| 1.2       | 4.0                      |
</details>

Figure 10. Radiation coefficients for term 55.

![](images/6d47ace98567ef57f35be4ab439f18db9b0d10df3196b3d404e275ee3c3bad5e.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | HyS 0kn | Cap 0kn | HyS 10kn | Cap 10kn |
| --------- | ------- | ------- | -------- | -------- |
| 0.0       | 0       | 0       | 0        | 0        |
| 0.2       | ~0.1    | ~0.1    | ~0.1     | ~0.1     |
| 0.4       | ~1.8    | ~1.7    | ~1.7     | ~1.6     |
| 0.6       | ~2.2    | ~2.1    | ~2.0     | ~1.9     |
| 0.8       | ~1.2    | ~1.3    | ~1.1     | ~1.0     |
| 1.0       | ~0.6    | ~0.7    | ~0.5     | ~0.4     |
| 1.2       | ~0.3    | ~0.4    | ~0.2     | ~0.1     |
</details>

![](images/754abbbe19c9a664e888cde53d574ff0daefaf108e1aee858a46d3adab748b96.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | Phase [deg] |
| --------- | ----------- |
| 0.0       | 270         |
| 0.2       | 270         |
| 0.4       | 90          |
| 0.6       | 0           |
| 0.8       | 180         |
| 1.0       | 360         |
| 1.2       | 90          |
</details>

Figure 11. Diffraction complex forces for surge.

![](images/f42a0a97536d9cd0528246373b9c9c04ed1a424951febc5bc418ac83e360c452.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | HyS 0kn | Cap 0kn | HyS 10kn | Cap 10kn |
| --------- | ------- | ------- | -------- | -------- |
| 0.0       | 0       | 0       | 0        | 0        |
| 0.2       | ~8×10⁵  | ~8×10⁵  | ~8×10⁵   | ~8×10⁵   |
| 0.4       | ~14×10⁶ | ~14×10⁶ | ~14×10⁶  | ~14×10⁶  |
| 0.6       | ~2×10⁵  | ~2×10⁵  | ~2×10⁵   | ~2×10⁵   |
| 0.8       | ~6×10⁴  | ~6×10⁴  | ~6×10⁴   | ~6×10⁴   |
| 1.0       | ~2×10⁵  | ~2×10⁵  | ~2×10⁵   | ~2×10⁵   |
| 1.2       | ~2×10⁵  | ~2×10⁵  | ~2×10⁵   | ~2×10⁵   |
</details>

![](images/ed8a9ff8532f398729c90aeb50472e6038be43c1209d48244771097f249b15d1.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | Phase [deg] |
| --------- | ----------- |
| 0.0       | 180         |
| 0.2       | 175         |
| 0.4       | 170         |
| 0.6       | 270         |
| 0.8       | 260         |
| 1.0       | 250         |
| 1.2       | 90          |
</details>

Figure 12. Diffraction complex forces for heave.

![](images/518cd785efc70f5f76c46bb359f7b3d016c32e63f9af547f46de67961fb6b952.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | HyS 0kn | Cap 0kn | HyS 10kn | Cap 10kn |
| --------- | ------- | ------- | -------- | -------- |
| 0.0       | 0       | 0       | 0        | 0        |
| 0.2       | ~1×10⁷  | ~1×10⁷  | ~1×10⁷   | ~1×10⁷   |
| 0.4       | ~6×10⁷  | ~7×10⁷  | ~7×10⁷   | ~7×10⁷   |
| 0.6       | ~10×10⁸ | ~9×10⁸  | ~8×10⁸   | ~7×10⁸   |
| 0.8       | ~3×10⁸  | ~5×10⁸  | ~4×10⁸   | ~3×10⁸   |
| 1.0       | ~3×10⁸  | ~3×10⁸  | ~2×10⁸   | ~2×10⁸   |
| 1.2       | ~1×10⁸  | ~1×10⁸  | ~1×10⁸   | ~1×10⁸   |
</details>

![](images/b8135df9f1876fe8a0f40f179e9e7a9e5a5959b2b278dfbb58ac27c2287df628.jpg)

<details>
<summary>line</summary>

| ω [rad/s] | Phase [deg] (Solid Line) | Phase [deg] (Dashed Line) |
| --------- | ------------------------ | ------------------------- |
| 0.0       | 270                      | 180                       |
| 0.2       | 240                      | 160                       |
| 0.4       | 180                      | 120                       |
| 0.6       | 0                        | 0                         |
| 0.8       | 360                      | 180                       |
| 1.0       | 360                      | 180                       |
| 1.2       | 90                       | 90                        |
</details>

Figure 13. Diffraction complex forces for pitch.

# 4.2 DIFFRACTION FORCES

The results of diffraction complex forces for the surge, heave and pitch degrees of freedom outlined an almost perfect match between the modified version of Capytaine and HydroStar, as shown in Figure 11 to Figure 13.

# 5 CONCLUSIONS

This paper describes the first implementation of forward speed effects in an open source 3D panel seakeeping code. The AFS method, which is only partially described in literature, was investigated in detail by performing a literature review and re-writing the method from scratch, paying particular attention to correctly define the conventions used.

Then, the open source code Capytaine was modified in order to implement the AFS method. The modified version of the Capytaine code was used to simulate the seakeeping behavior of the KCS ship in head waves with a forward speed of 10 knots. The results obtained with the modified version of Capytaine were compared with the results coming from the commercial code HydroStar, which already includes the effects of forward speed but is a closed code and as such less suitable for research purposes. When comparing the two codes, the different conventions adopted in the codes were investigated and properly accounted for. The comparison of the results outlined a good agreement of both the radiation coefficients and the excitation forces.

Implementing forward speed effects in an open source 3D panel code can extend its usefulness to a much wider list of applications. These applications include, among others, the estimation of the seakeeping behaviour of ships underway, in both deep and shallow water, or the calculation of fluid forces acting on fixed objects subjected to waves and current, like the monopile foundations of offshore wind turbines.

The analysis in this paper was focused on one ship, one wave encounter direction, one speed and one water depth. Other ships, headings, water depths and speeds will be tested and published in the near future. Moreover, the comparison will be extended to motion RAOs and drift forces, and experimental results in shallow water will be used to fully validate the code.

# 6 ACKNOWLEDGEMENTS

The main author participated to the present work in the frame of project WL\_2017\_06 (Scientific support for the implementation of seakeeping in the ship manoeuvring simulators), granted to Ghent University by Flanders Hydraulics Research, Antwerp (Department of Mobility and Public Works, Flemish Government, Belgium).

# 7 REFERENCES

Ancellin, M., Dias, F., 2019. Capytaine: a Python-based linear potential flow solver. JOSS 4, 1341. https://doi.org/10.21105/joss.01341   
Babarit, A., Delhommeau, G., 2015. Theoretical and numerical aspects of the open source BEM solver NEMOH, in: Proceedings of the 11th European Wave and Tidal Energy Conference (EWTEC). Nantes, France.   
Beck, R.F., Reed, A.M., 2001. Modern Computational Methods for Ships in a Seaway. Transactions SNAME 109, 1–51.   
Bertram, V., Veelo, B., Söding, H., Graf, K., 2006. Development of a freely available strip method for seakeeping, in: Proceedings of the 5th International Conference on Computer Applications and Information Technology in the Maritime Industries (COMPIT). Delft University of Technology, Oegstgeest, The Netherlands, pp. 356–368.   
Bunnik, T., van Daalen, E., Kapsenberg, G., Shin, Y., Huijsmans, R.H.M., Deng, G., Delhommeau, G., Kashiwagi, M., Beck, R.F., 2010. A comparative study on state-of-the-art prediction tools for seakeeping, in: Proceedings of the 28th Symposium on Naval Hydrodynamics (SNH). ONR, Pasadena, California (USA).   
Chapchap, A., Ahmed, T.M., Hudson, D.A., Temarel, P., Hirdaris, S.E., 2011. The Influence of Forward Speed and Non-linearities on the Dynamic Behaviour of a Container Ship in Regular Waves. Transactions RINA, International Journal Maritime Engineering 153. https://doi.org/10.3940/rina.ijme.2011.a2.wf8   
Chen, X., 2011. Offshore hydrodynamics and applications. The IES Journal Part A: Civil & Structural Engineering 4, 124–142. https://doi.org/10.1080/19373260.2011.595903   
Datta, R., Fonseca, N., Guedes Soares, C., 2013. Analysis of the forward speed effects on the radiation forces on a Fast Ferry. Ocean Engineering 60, 136–148. https://doi.org/10.1016/j.oceaneng.2012.11.010   
Emmerhoff, O.J., Sclavounos, P.D., 1992. The slow-drift motion of arrays of vertical cylinders. Journal of Fluid Mechanics 242, 31–50. https://doi.org/10.1017/S002211209200226X   
Gourlay, T., Lataire, E., Delefortrie, G., Donatini, L., Tello Ruiz, M., Veen, D., Bunnik, T., Dallinga, R.P., 2019. Benchmarking of DIFFRAC, FATIMA, HydroSTAR, MOSES, NEMOH, OCTOPUS, PDStrip, RAPID, SEAWAY, SlenderFlow and WAMIT against measured vertical motions of the Duisburg Test Case container ship in shallow water, in: Proceedings of the 5th

International Conference on Ship Manoeuvring in Shallow and Confined Water (MASHCON). Ostend, Belgium.   
Hasnan, M.A.A., Yasukawa, H., Hirata, N., Terada, D., Matsuda, A., 2020. Study of ship turning in irregular waves. J. Mar. Sci. Technol. 25, 1024–1043. https://doi.org/10.1007/s00773-019-00698-1   
Hizir, O., 2015. Three Dimensional Time Domain Simulation of Ship Motions and Loads in Large Amplitude Head Waves (PhD Thesis). University of Strathclyde, Glasgow, Scotland.   
Hizir, O., Kim, M., Turan, O., Day, A., Incecik, A., Lee, Y., 2019. Numerical studies on non-linearity of added resistance and ship motions of KVLCC2 in short and long waves. Int. J. Nav. Archit. Ocean Eng. 11, 143–153. https://doi.org/10.1016/j.ijnaoe.2018.02.015   
Iwashita, H., Ohkusu, M., 1992. The Green function method for ship motions at forward speed. Schiffstechnik (Ship Technology Research) 39, 3–21.   
Kim, Yonghwan, Kim, K.-H., Kim, J.-H., Kim, T., Seo, M.-G., Kim, Yooil, 2011. Time-domain analysis of nonlinear motion responses and structural loads on ships and offshore structures: development of WISH programs. International Journal of Naval Architecture and Ocean Engineering 3, 37–52. https://doi.org/10.2478/IJNAOE-2013-0044   
Liu, Y., 2019. HAMS: A Frequency-Domain Preprocessor for Wave-Structure Interactions—Theory, Development, and Application. JMSE 7, 81. https://doi.org/10.3390/jmse7030081   
Malenica, š., Chen, X.B., 1998. On the Irregular Frequencies Appearing In Wave Diffraction-Radiation Solutions. International Journal of Offshore and Polar Engineering 8.   
Mantzaris, D.A., 1998. A Rankine Panel Method as a Tool for the Hydrodynamic Design of Complex Marine Vehicles (PhD Thesis). Massachusetts Institute of Technology.   
Nakos, D.E., 1990. Ship wave patterns and motions by a three dimensional Rankine panel method (PhD Thesis). Massachusetts Institute of Technology.   
Nossen, J., Grue, J., Palm, E., 1991. Wave forces on threedimensional floating bodies with small forward speed. Journal of Fluid Mechanics 227, 135–160. https://doi.org/10.1017/S002211209100006X   
Papanikolaou, A., Schellin, T.E., 1992. A Three-Dimensional Panel Method for Motions and Loads of Ships with Forward Speed. Ship Technology Research 39, 147–156.

Raven, H.C., 1996. A Solution Method for the Nonlinear Ship Wave Resistance Problem (PhD Thesis). Delft University of Technology.

Salvesen, N., Tuck, E.O., Faltinsen, O.M., 1970. Ship Motions and Sea Loads. Transactions SNAME 78.

SIMMAN 2008, n.d. MOERI Container Ship [WWW Document]. http://www.simman2008.dk/KCS/container.html (accessed 1.1.22).

Simonsen, C.D., Otzen, J.F., Joncquez, S., Stern, F., 2013. EFD and CFD for KCS heaving and pitching in regular head waves. J. Mar. Sci. Technol. 18, 435–459. https://doi.org/10.1007/s00773-013-0219-0

Söding, H., von Graefe, A., el Moctar, O., Shigunov, V., 2012. Rankine Source Method for Seakeeping Predictions, in: Proceedings of the 31st International Conference on Offshore Mechanics and Arctic Engineering (OMAE). American Society of Mechanical Engineers, Rio de Janeiro, Brazil, pp. 449–460. https://doi.org/10.1115/OMAE2012-83450

Stocker, M.R., 2016. Surge free added resistance tests in oblique wave headings for the KRISO container ship model (Master Thesis). University of Iowa.

Tuitman, J.T., Malenica, Š., 2009. Fully coupled seakeeping, slamming, and whipping calculations. Proceedings of the Institution of Mechanical Engineers, Part M: Journal of Engineering for the Maritime Environment 223, 439–456. https://doi.org/10.1243/14750902JEME153

Xie, C., Choi, Y., Rongère, F., Clément, A.H., Delhommeau, G., Babarit, A., 2018. Comparison of existing methods for the calculation of the infinite water depth free-surface Green function for the wave–structure interaction problem. Applied Ocean Research 81, 150– 163. https://doi.org/10.1016/j.apor.2018.10.007

# 8 AUTHORS BIOGRAPHY

Luca Donatini, naval architect, is a PhD student at Ghent University. He is currently working on a project aimed at the implementation of spectral waves and seakeeping in the ship manoeuvring simulator of Flanders Hydraulic Research. His previous experiences encompass seakeeping studies to allow inland vessels on a Belgian sea trajectory and the inclusion of hydro/meteo effects in an open source mooring dynamics code. He also has an extensive experience in atmospheric and spectral wave modelling from global to regional scales.

Ivandito Herdayanditya, energy engineer, is currently doing a joint PhD research between KU Leuven and Ghent University. His research project focuses on the operability of a vessel which is located near an offshore wind turbine and under the waves and current environmental loads. His previous research experience was about fully nonlinear potential flow analysis for a submerged waves energy converter which was conducted for his master thesis.

Gael Verao Fernandez, PhD, civil engineer, holds the position of post-doctoral researcher at the Coastal Engineering, Bridges and Roads Research Group of Ghent University. His previous experience includes numerical modelling of Wave Energy Converters farms for studying coastal impacts and the inclusion of a time-domain body motion solver in an open source mooring dynamics code.

Ajie Brama Krishna Pribadi, naval architect, is a Research Staff at the Maritime Technology Division of Ghent University. He is currently undertaking different projects that focus on the mooring optimizations of mussels and seaweeds aquaculture as well as floating offshore solar panel. He is also actively involved in the development of an in-house time-domain mooring dynamic software used in the aforementioned projects.

Evert Lataire, Prof., naval architect, is currently head of the Maritime Technology Division at Ghent University. He has written a PhD on the topic of bank effects mainly based upon model tests carried out in the shallow water towing tank of FHR. His fifteen year experience includes research on ship manoeuvring in shallow and confined water such as ship-ship interaction, shipbottom interaction and ship-bank interaction.

Guillaume Delefortrie, PhD, naval architect, is expert nautical researcher at Flanders Hydraulics Research and visiting professor at Ghent University. He is in charge of the research in the Towing Tank for Manoeuvres in Confined Water and the development of mathematical models based on model tests. He has been a member of the 27th to 29th ITTC Manoeuvring Committees.